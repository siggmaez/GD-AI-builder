# GD AI Builder v0.1 — Android ARM64

Prototype Geode mod for Geometry Dash Android 64-bit. Adds an **AI** button in the editor and a test popup. **No AI functionality yet.**

## Build on GitHub (from a phone)

1. Create a new GitHub repository (public or private).
2. Extract this ZIP. Upload **the contents of `GD-AI-Builder-v0.1`** to the repository root, including the `.github/workflows/android64.yml` file. GitHub's web uploader may hide dotfolders on some file pickers; check the Actions tab to confirm the workflow exists.
3. Open **Actions → Build Android ARM64 → Run workflow**. It also starts automatically after a push to `main`.
4. If the build succeeds, open its run and download the **GD-AI-Builder-Android64** artifact. Extract the ZIP to get the `.geode` mod.
5. Import the `.geode` mod using the Geode mod installer, or copy it to the Android Geode mods folder appropriate for your installation.

This source has not been compiled or tested on a device. If Actions reports a compilation error, share the build log to fix it.

Only `Android64` is targeted; no Android32 build is configured.
