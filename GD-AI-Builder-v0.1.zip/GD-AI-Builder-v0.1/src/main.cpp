#include <Geode/Geode.hpp>
#include <Geode/modify/EditorUI.hpp>
#include <Geode/binding/FLAlertLayer.hpp>
#include <Geode/binding/ButtonSprite.hpp>
#include <Geode/binding/CCMenuItemSpriteExtra.hpp>

using namespace geode::prelude;

class $modify(AIBuilderEditorUI, EditorUI) {
    bool init(LevelEditorLayer* editor) {
        if (!EditorUI::init(editor)) return false;

        auto win = CCDirector::sharedDirector()->getWinSize();
        auto menu = CCMenu::create();
        menu->setID("gd-ai-builder-menu"_spr);
        menu->setPosition({win.width - 35.f, win.height / 2.f + 70.f});

        auto button = CCMenuItemSpriteExtra::create(
            ButtonSprite::create("AI"),
            this,
            menu_selector(AIBuilderEditorUI::onAIBuilder)
        );
        button->setID("gd-ai-builder-button"_spr);
        menu->addChild(button);
        this->addChild(menu, 100);
        return true;
    }

    void onAIBuilder(CCObject*) {
        FLAlertLayer::create(
            "GD AI Builder v0.1",
            "<cg>Android ARM64 prototype</c>\n\n"
            "The AI button is working!\n"
            "Chat and editor controls are coming next.",
            "Close"
        )->show();
    }
};
